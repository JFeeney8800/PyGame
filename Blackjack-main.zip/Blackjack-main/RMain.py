
import math
import random
import pygame
from pygame.locals import *
import sys

# === Game Configuration Constants ===
# Cost in player bank to use the Sabotage action.
SABOTAGE_COST = 25
# The key press required to trigger the Sabotage action (K_s means the 'S' key).
SABOTAGE_KEY = K_s

# === Card Class ===
# Represents a single playing card in the game.
class Card:
    # Constructor: Initializes a new card object.
    # Takes suit (e.g., "Heart"), color ("Red"), label ("K"), and value (10) as input.
    def __init__(self, suit, color, label, value):
        self.suit = suit    # e.g., "Spade", "Heart"
        self.color = color  # e.g., "Black", "Red"
        self.label = label  # e.g., "A", "K", "7"
        self.value = value  # Blackjack value (e.g., Ace=1 or 11, K=10)

# === Deck Class ===
# Represents the deck of playing cards.
class Deck:
    # Constructor: Initializes an empty list to hold the cards.
    def __init__(self):
        self.cards = []

    # Creates a standard 52-card deck.
    def createDeck(self):
        self.cards = [] # Ensure deck is empty before creating
        suits = ["Clover", "Spade", "Heart", "Diamond"]
        # Loop through each suit
        for symbol in suits:
            # Loop through card numbers (2-10, J, Q, K, A)
            # We use 11=J, 12=Q, 13=K, 14=A internally for easier looping.
            number = 2
            while number < 15:
                # Determine card color based on suit.
                if symbol == "Clover" or symbol == "Spade":
                    suitColor = "Black"
                else:
                    suitColor = "Red"

                # Determine Blackjack value.
                value = number
                if number > 10: # J, Q, K are worth 10
                    value = 10
                if number == 14: # Ace is initially worth 1 (adjusted later in counting)
                    value = 1 # Changed to 1, counting logic handles 11

                # Determine card label (e.g., "J", "Q", "K", "A").
                letter = str(number)
                if number == 11:
                    letter = "J"
                elif number == 12:
                    letter = "Q"
                elif number == 13:
                    letter = "K"
                elif number == 14:
                    letter = "A"

                # Create the new Card object and add it to the deck.
                newCard = Card(symbol, suitColor, letter, value)
                self.cards.append(newCard)
                number += 1

    # Shuffles the deck randomly.
    def shuffleDeck(self):
        random.shuffle(self.cards)

    # Removes and returns the top card from the deck.
    # If the deck is empty, it creates and shuffles a new one automatically.
    def getCard(self):
        # Check if deck is empty.
        if not self.cards:
             print("Deck empty, reshuffling!")
             self.createDeck()
             self.shuffleDeck()

        # Double-check if still empty after trying to reshuffle (shouldn't happen).
        if not self.cards:
             print("CRITICAL ERROR: Deck empty even after reshuffle!")
             # Return None to indicate a problem.
             return None

        # Remove the first card (index 0) from the list and return it.
        topCard = self.cards.pop(0)
        return topCard


# === Dealer Class ===
# Represents the dealer in the game. Manages the deck and their own hand.
class Dealer:
    # Constructor: Initializes the dealer.
    def __init__(self):
        self.deck = Deck()          # Creates a new Deck object for the dealer.
        self.deck.createDeck()      # Fills the deck with 52 cards.
        self.deck.shuffleDeck()     # Shuffles the deck.
        self.hand = []              # Dealer's current hand (list of Card objects).
        self.count = 0              # Dealer's current hand value.
        self.blackjack = False      # Flag: True if dealer gets Blackjack (21 on first 2 cards).
        # Screen position for drawing the dealer's hand.
        self.x = halfWidth          # Center horizontally.
        self.y = 150                # Vertical position near the top.

    # Resets dealer's hand, deals two cards, and checks for Blackjack.
    def createDealerHand(self):
        self.hand = []              # Clear any previous hand.
        self.count = 0              # Reset count.
        self.blackjack = False      # Reset Blackjack flag.
        # Deal two cards to the dealer.
        for _ in range(2):
            card = self.dealCard()
            if card: # Make sure a card was successfully dealt
                 self.addCardToHand(card)
            else:
                 # This is a critical error if it happens during initial deal.
                 print("Error dealing initial dealer card - deck empty?")
                 return False # Signal failure

        # Calculate the value of the initial hand.
        self.countCards()
        # Check if the initial two cards make 21 (Blackjack).
        if self.count == 21 and len(self.hand) == 2:
            self.blackjack = True
            print("Dealer Blackjack!")
        return True # Signal success


    # Deals one card from the dealer's deck. (Wrapper for deck.getCard)
    def dealCard(self):
        return self.deck.getCard()

    # Adds a given card object to the dealer's hand and updates the count.
    def addCardToHand(self, card):
         if card: # Only add if it's a valid Card object
             self.hand.append(card)
             self.countCards() # Recalculate count immediately.

    # Simulates the dealer taking another card (hitting).
    def hit(self):
         print("Dealer hits.")
         card = self.dealCard() # Get card from deck.
         self.addCardToHand(card) # Add to hand and update count.

    # Prints the dealer's hand to the console (for debugging/logging).
    def printDealerHand(self):
        print("\nDealer's Hand: ")
        # Create a list of (label, suit) tuples for easy reading.
        # Handle potential None cards just in case.
        hand_str = [(card.label, card.suit) for card in self.hand if card]
        print(hand_str)

    # Prints the dealer's current hand value to the console.
    def printDealerCount(self):
        print(f"Dealer's Count: {self.count}")

    # Calculates the dealer's hand value, handling Aces correctly.
    # Aces can be 1 or 11. The logic tries to use 11 unless it causes a bust.
    def countCards(self):
        self.count = 0
        ace_count = 0 # Track how many Aces are in the hand.
        # Iterate through each card in the hand.
        for card in self.hand:
             if not card: continue # Safety check for None cards.
             # If it's an Ace:
             if card.label == 'A':
                ace_count += 1
                # Add 11 for Ace initially. We'll adjust later if needed.
                self.count += 11
             else:
                # For non-Ace cards, add their value.
                # Use try-except for safety in case value isn't an integer.
                try:
                    self.count += int(card.value)
                except (ValueError, TypeError):
                     # Log a warning if a card has an unexpected value.
                     print(f"Warning: Dealer Card {card.label} has non-integer value {card.value}")

        # Adjust for Aces if the total count is over 21.
        # While the count is too high AND we have Aces currently counted as 11:
        while self.count > 21 and ace_count > 0:
            self.count -= 10 # Change one Ace's value from 11 to 1.
            ace_count -= 1 # Decrement the count of Aces acting as 11.

    # Draws the dealer's hand onto the Pygame screen.
    # 'revealed' determines if the second card is shown face up (True) or face down (False).
    def drawHand(self, surface, revealed=False):
        # Define card dimensions and spacing for drawing.
        cardWidth, cardHeight = 78, 120
        cardGap = 20 # Horizontal gap between cards.
        if not self.hand: return # Don't try to draw if the hand is empty.

        hand_size = len(self.hand)
        # Calculate the total width the hand will take up on screen.
        total_width = cardWidth + (cardGap * (hand_size - 1)) if hand_size > 0 else cardWidth
        # Calculate the starting X and Y coordinates to center the hand visually.
        start_x = self.x - (total_width / 2)
        start_y = self.y - (cardHeight / 2)

        # Loop through each card and draw it.
        for i, card in enumerate(self.hand):
            if not card: continue # Skip None cards.
            image_path = ""
            # Determine whether to show the card's face or back.
            # The first card (i=0) is always shown.
            # Subsequent cards are shown only if 'revealed' is True.
            # Exception: If only one card exists, always show it.
            if i == 0 or revealed or len(self.hand) == 1:
                 # Construct the file path for the card's face image.
                 image_path = f"Resources/Cards/{card.suit}/{card.label}.png"
            else: # Draw the card back for the hidden card (usually the second one).
                 # Path to the card back image.
                 image_path = "Resources/Cards/Back/red_back.png"

            # Load the image, resize it, and draw ("blit") it onto the surface.
            try:
                drawCard = pygame.image.load(image_path)
                resizedCard = pygame.transform.scale(drawCard, (cardWidth, cardHeight))
                # Draw at the calculated position (start_x + offset for each card).
                surface.blit(resizedCard, (start_x + i * cardGap, start_y))
            except pygame.error as e:
                # If image loading fails, print an error and draw a red placeholder rectangle.
                print(f"Error loading/drawing dealer card image: {image_path} - {e}")
                pygame.draw.rect(surface, red, (start_x + i * cardGap, start_y, cardWidth, cardHeight), 1)
            except Exception as e:
                 # Catch any other potential errors during drawing.
                 print(f"General error drawing dealer card: {e}")

        # Add text below the dealer's hand (Name and Count).
        nameX = self.x # Center the text horizontally with the hand.
        nameY = self.y + (0.75 * cardHeight) # Position below the cards.
        dealer_text = "DEALER"
        # Only show the count if the hand is fully revealed.
        if revealed:
            dealer_text += f" ({self.count})"
        # Use the helper function to draw the text.
        add_text(dealer_text, text_Normal, surface, nameX, nameY, white)

        # Optional: Draw an image representing the deck.
        try:
            deck_img_path = "Resources/Cards/Back/red_back.png"
            deckCard = pygame.image.load(deck_img_path)
            backCard = pygame.transform.scale(deckCard, (cardWidth, cardHeight))
            # Position the deck image (e.g., top right corner).
            deck_x_pos = screenWidth - cardWidth - 30
            deck_y_pos = 50
            surface.blit(backCard, (deck_x_pos, deck_y_pos))
            # Add a "DECK" label below the image.
            add_text("DECK", text_Small, surface, deck_x_pos + cardWidth/2, deck_y_pos + cardHeight + 10, white)
        except pygame.error as e:
            # Log error if deck image fails to load/draw.
            print(f"Error loading/drawing deck image: {deck_img_path} - {e}")
        except Exception as e:
            # Catch other potential errors drawing the deck.
            print(f"General error drawing deck: {e}")


# === Player Class ===
# Represents a player in the game.
class Player:
    # Constructor: Initializes a new player.
    def __init__(self, name):
        self.name = name            # Player's chosen name.
        self.hand = []              # Player's current hand.
        self.count = 0              # Player's current hand value.
        self.blackjack = False      # Flag: True if player gets Blackjack.
        self.bust = False           # Flag: True if player's count exceeds 21.
        self.stood = False          # Flag: True if player chooses to Pass/Stand.
        self.bank = 100             # Starting amount of money.
        self.bet = 0                # Amount bet for the current round.
        # Screen position (assigned later by fixCoordinates).
        self.x = 0
        self.y = 0
        self.currentTurn = False    # Flag: True if it's this player's turn.
        self.is_out = False         # Flag: True if player is bankrupt and out of the game.

    # Waits for player input (key press) to choose an action (Hit, Pass, Sabotage).
    # Returns: 1 for Hit, 2 for Pass, 3 for Sabotage, 0 for Quit/Error.
    def askChoice(self):
        inp = 0 # Default return value (no choice made yet).
        answered = False
        # Event loop: Continuously checks for keyboard events.
        while not answered:
            pygame.time.Clock().tick(30) # Limit loop speed to prevent high CPU usage.
            for event in pygame.event.get():
                # Allow quitting the game at any time.
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit()
                    sys.exit() # Exit the program immediately.
                # Check for specific key presses for actions.
                if event.type == KEYDOWN:
                    if event.key == K_h: # 'H' key for Hit.
                        inp = 1
                        answered = True
                    elif event.key == K_p: # 'P' key for Pass/Stand.
                        inp = 2
                        answered = True
                    elif event.key == SABOTAGE_KEY: # The key defined for Sabotage (e.g., 'S').
                        inp = 3
                        answered = True
            # Loop continues until H, P, or S is pressed.
        return inp

    # Adds a given card object to the player's hand and updates count.
    def addCard(self, card):
        if card: # Ensure the card is valid.
            self.hand.append(card)
            self.countCards() # Recalculate count every time a card is added.
        else:
             # Log a warning if trying to add an invalid card.
             print(f"Warning: {self.name} received an invalid card (None).")

    # Prints the player's hand, status, and count to the console.
    def printHand(self):
        # Determine the player's current status for display.
        status = "ACTIVE"
        if self.stood: status = "STAND"
        if self.bust: status = "BUST"
        if self.blackjack: status = "BLACKJACK"
        print(f"\n{self.name}'s Hand ({status}): ")
        # Print card labels and suits. Avoid errors if a card is None.
        hand_str = [(card.label, card.suit) for card in self.hand if card]
        print(hand_str)
        # Print current count.
        print(f"{self.name}'s Count: {self.count}")

    # Updates the player's bank based on the round outcome.
    # factor: 0 = Lose bet, 1 = Push (bet returned), 2 = Win (bet + winnings).
    def applyBet(self, factor):
        # Ensure the bet amount is treated as a number.
        try:
             current_bet = int(self.bet)
        except (ValueError, TypeError):
             current_bet = 0 # Default to 0 if bet is invalid.

        # Calculate how much the bank changes based on the outcome factor.
        bank_change = 0
        if factor == 0: # Lose bet
            bank_change = 0 # Bank doesn't increase.
        elif factor == 1: # Push
            bank_change = current_bet # Get the original bet back.
        elif factor == 2: # Win (Regular or Blackjack)
            bank_change = current_bet * 2 # Get original bet back + winnings equal to bet.

        # Update the player's bank balance.
        self.bank += bank_change

        # Reset the bet amount for the next round.
        self.resetBet()

    # Resets the player's bet amount to 0.
    def resetBet(self):
        self.bet = 0

    # Sets the player's bet for the round and deducts it from the bank.
    # Returns True if the bet is valid and placed, False otherwise.
    def placeBet(self, amount):
         # Check if the amount is positive and the player has enough money.
         if 0 < amount <= self.bank:
             self.bet = amount
             self.bank -= amount # Deduct the bet from the bank immediately.
             return True # Bet successfully placed.
         else:
             # Invalid bet amount or insufficient funds.
             print(f"Invalid bet for {self.name}: Amount ${amount}, Bank ${self.bank}")
             return False # Indicate bet failed.

    # Prints the player's current bank balance to the console.
    def printBank(self):
        print(f"{self.name}'s Bank: ${self.bank}")

    # Clears the player's hand and resets their count (used for new rounds).
    def resetHandAndCount(self):
        self.hand = []
        self.count = 0

    # Calculates the player's hand value, handling Aces correctly (same logic as Dealer).
    def countCards(self):
        self.count = 0
        ace_count = 0
        # Sum card values, count Aces as 11 initially.
        for card in self.hand:
            if not card: continue # Skip None cards.
            if card.label == 'A':
                ace_count += 1
                self.count += 11
            else:
                # Add value, handle potential non-integer values.
                try:
                    self.count += int(card.value)
                except (ValueError, TypeError):
                     print(f"Warning: Player {self.name} Card {card.label} has non-integer value {card.value}")

        # Adjust count if over 21 and Aces counted as 11 are present.
        while self.count > 21 and ace_count > 0:
            self.count -= 10 # Convert an Ace from 11 to 1.
            ace_count -= 1

    # Draws the player's hand, name, bank, bet, and status on the Pygame screen.
    def drawHand(self, surface):
        # Don't draw anything if the player is out of the game.
        if self.is_out:
             # Optionally, you could draw "OUT" text here.
             # add_text(f"{self.name} (OUT)", text_Normal, surface, self.x, self.y, (100,100,100))
             return
        # Don't draw if the hand is empty (unless out, handled above).
        if not self.hand: return

        # Card dimensions and spacing.
        cardWidth, cardHeight = 78, 120
        cardGap = 20
        # Calculate total width needed for the cards. Handle 0 or 1 card case.
        playerBoxLength = cardWidth + (cardGap * (max(0, len(self.hand) - 1)))
        # Calculate top-left X, Y coordinates to center the hand horizontally/vertically.
        playerTopLeftX = self.x - (0.5 * playerBoxLength)
        playerTopLeftY = self.y - (0.5 * cardHeight)

        # Draw each card in the hand.
        for i, card in enumerate(self.hand):
            if not card: continue # Skip None cards.
            try:
                # Construct image path, load, resize, and blit the card.
                img_path = f"Resources/Cards/{card.suit}/{card.label}.png"
                drawCard = pygame.image.load(img_path)
                resizedCard = pygame.transform.scale(drawCard, (cardWidth, cardHeight))
                surface.blit(resizedCard, (playerTopLeftX + i * cardGap, playerTopLeftY))
            except pygame.error as e:
                 # Log error and draw placeholder if image fails.
                 print(f"Error loading/drawing card {card.label} {card.suit}: {e}")
                 pygame.draw.rect(surface, red, (playerTopLeftX + i * cardGap, playerTopLeftY, cardWidth, cardHeight), 1)
            except Exception as e:
                 # Catch other drawing errors.
                 print(f"General error drawing player card: {e}")

        # --- Display Text Information for the Player ---
        nameX = self.x # Center text horizontally.
        nameY = self.y + (0.75 * cardHeight) # Position text below the cards.
        nameColor = white # Default text color.
        action_text = "" # Text to show available actions.

        # If it's this player's turn:
        if self.currentTurn:
            nameColor = blue # Highlight the current player's name.
            # Construct the action prompt string, including Sabotage cost.
            sabotage_key_name = pygame.key.name(SABOTAGE_KEY).upper() # Get 'S' from K_s
            action_text = f"Hit(H) Pass(P) Sabotage({sabotage_key_name})-${SABOTAGE_COST}"
            # Position the action text above the player's hand.
            add_text(action_text, text_Normal, surface, self.x, self.y - (0.75 * cardHeight), nameColor)

        # Display Player Name and Bank Balance.
        player_info = f"{self.name} (${self.bank})"
        # If a bet is placed, display it too.
        if self.bet > 0:
            player_info += f" Bet: ${self.bet}"
        add_text(player_info, text_Normal, surface, nameX, nameY, nameColor)

        # Display Player's Count and Stand Status.
        countY = nameY + 25 # Position below name/bank line.
        status_str = f"Count: {self.count}"
        if self.stood: # Indicate if the player has chosen to stand.
             status_str += " (Stand)"
        add_text(status_str, text_Normal, surface, nameX, countY, white)

        # --- Display Status Overlays (Bust/Blackjack Images) ---
        status_overlay_img = None # Path to the overlay image, if any.
        if self.bust:
            status_overlay_img = "Resources/Icons/bust.png"
        elif self.blackjack:
             status_overlay_img = "Resources/Icons/blackjack.png"

        # Load and draw the overlay image if one is needed.
        if status_overlay_img:
             try:
                status_overlay = pygame.image.load(status_overlay_img)
                # Get the rectangle of the overlay image and center it over the player's area.
                overlayRect = status_overlay.get_rect(center=(self.x, self.y))
                # Draw the overlay onto the main surface.
                surface.blit(status_overlay, overlayRect)
             except pygame.error as e:
                 # Log error if overlay image fails to load.
                 print(f"Error loading status overlay {status_overlay_img}: {e}")
             except Exception as e:
                 # Catch other errors during blitting.
                 print(f"Error blitting status overlay: {e}")

    # Resets the player's state for the start of a new round.
    def resetState(self):
        self.bust = False           # Reset bust flag.
        self.blackjack = False      # Reset blackjack flag.
        self.stood = False          # Reset stood flag.
        self.resetHandAndCount()    # Clear hand and count.
        self.currentTurn = False    # Ensure not marked as current turn initially.
        # Note: Bet is reset elsewhere (in applyBet or before betting phase).

    # --- Optional Point Transfer Method ---
    # Allows a player to give money to another player (if feature is desired).
    def givePoints(self, recipient_player, amount):
        # Validate the transfer request.
        if amount <= 0: return False, "Amount must be positive."
        if self.bank < amount: return False, "Insufficient funds."
        if recipient_player is self: return False, "Cannot give to self."
        # Ensure recipient is a valid Player object and is still in the game.
        if not isinstance(recipient_player, Player) or recipient_player.is_out:
            return False, "Invalid recipient."

        # Perform the transfer.
        self.bank -= amount
        recipient_player.bank += amount
        # Log the transfer to the console.
        print(f"{self.name} gave ${amount} to {recipient_player.name}.")
        return True, f"Successfully gave ${amount} to {recipient_player.name}."

    # --- Optional Player Penalize Bank Method ---
    # Example: Allows player to spend money to reduce another's bank (if desired).
    # def penalizePlayer(self, target_player, penalty_amount, cost_to_penalizer):
    #     # Validate amounts and funds
    #     if cost_to_penalizer < 0 or penalty_amount < 0: return False, "Amounts must be non-negative."
    #     if self.bank < cost_to_penalizer: return False, "Insufficient funds to penalize."
    #     if target_player is self: return False, "Cannot penalize yourself."
    #     if not isinstance(target_player, Player) or target_player.is_out: return False, "Invalid target."
    #     # Execute penalty
    #     self.bank -= cost_to_penalizer
    #     target_player.bank = max(0, target_player.bank - penalty_amount) # Prevent going below 0.
    #     print(f"{self.name} paid ${cost_to_penalizer} to penalize {target_player.name} by ${penalty_amount}.")
    #     return True, f"Successfully penalized {target_player.name}."


# --- Pygame Initialization and Global Variables ---
pygame.init()      # Initialize all Pygame modules.
pygame.font.init() # Initialize the font system specifically.

# Define screen dimensions.
screenWidth, screenHeight = 1350, 800
# Calculate center coordinates for convenience.
halfWidth, halfHeight = screenWidth / 2, screenHeight / 2

# Load the background image. Use try-except for robustness.
try:
    pokerBackgroundOriginal = pygame.image.load("Resources/Icons/pokerBackground3.jpg")
    # Scale the background image to fit the screen dimensions.
    pokerGreen = pygame.transform.scale(pokerBackgroundOriginal, (screenWidth, screenHeight))
except pygame.error as e:
    print(f"Error loading background image: {e}")
    # If loading fails, create a plain green surface as a fallback.
    pokerGreen = pygame.Surface((screenWidth, screenHeight))
    pokerGreen.fill((0, 100, 0)) # Dark green color.

# Define frequently used colors using RGB tuples.
black, blue, white, orange, red = (0, 0, 0), (51, 235, 255), (255, 255, 255), (255, 165, 0), (255, 0, 0)

# Define fonts for different text sizes. Use try-except for font availability.
fontType = 'Comic Sans MS' # Desired font family.
try:
    # Create font objects with specified family and size.
    text_Title = pygame.font.SysFont(fontType, 80)
    text_Heading = pygame.font.SysFont(fontType, 60)
    text_SubHeading = pygame.font.SysFont(fontType, 45)
    text_Bold = pygame.font.SysFont(fontType, 30)
    text_Normal = pygame.font.SysFont(fontType, 20)
    text_Small = pygame.font.SysFont(fontType, 15)
except pygame.error as e:
     # If the desired font isn't found, use the default system font.
     print(f"Warning: Font '{fontType}' not found, using default. {e}")
     text_Title=pygame.font.SysFont(None, 80); text_Heading=pygame.font.SysFont(None, 60); text_SubHeading=pygame.font.SysFont(None, 45); text_Bold=pygame.font.SysFont(None, 30); text_Normal=pygame.font.SysFont(None, 20); text_Small=pygame.font.SysFont(None, 15)

# --- Global Game Objects ---
# List to hold all Player objects participating in the game.
players = []
# Create the single Dealer instance for the game.
dealer = Dealer()


# --- Utility Functions ---

# Helper function to render and draw text onto a surface.
# Simplifies adding text elements to the screen.
def add_text(text, font, surface, x, y, text_color, center_align=True):
    try:
        # Render the text into a surface object. True enables anti-aliasing (smoother edges).
        textSurface = font.render(text, True, text_color)
        # Get the rectangle bounding the text surface.
        textRect = textSurface.get_rect()
        # Position the text rectangle.
        if center_align:
            # Set the center of the text rectangle to the specified (x, y).
            textRect.center = (x, y)
        else:
            # Set the top-left corner of the text rectangle to (x, y).
            textRect.topleft = (x, y)
        # Draw the rendered text surface onto the main game surface.
        surface.blit(textSurface, textRect)
    except Exception as e:
        # Log an error if text rendering or blitting fails.
        print(f"Error rendering text '{text}': {e}")


# --- Game Setup Screens ---

# Function to display the initial welcome screen.
def startGame():
    # Create the main game window.
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    # Set the window title.
    pygame.display.set_caption("Welcome to Blackjack!")
    # Draw the background image/color.
    screen.blit(pokerGreen, (0, 0))
    # Try to load and display a title logo image.
    try:
        titleLogo = pygame.image.load("Resources/Icons/titleBlitzEdition.png")
        # Center the logo horizontally, position vertically above center.
        logoRect = titleLogo.get_rect(center=(halfWidth, halfHeight - 50))
        screen.blit(titleLogo, logoRect)
    except pygame.error as e:
        # If logo loading fails, print error and display text title instead.
        print(f"Error loading title logo: {e}")
        add_text("Blackjack Blitz!", text_Title, screen, halfWidth, halfHeight - 50, orange)

    # Display prompt text to continue.
    add_text("PRESS RETURN TO CONTINUE", text_SubHeading, screen, halfWidth, halfHeight + 100, white)
    # Update the entire screen to show the drawn elements.
    pygame.display.flip()

    # Wait loop: Keeps running until the user presses Return or quits.
    beginning = True
    while beginning:
        pygame.time.Clock().tick(30) # Limit loop speed.
        # Process events (like key presses, window close).
        for event in pygame.event.get():
            # Handle quit events (closing window or pressing Escape).
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit(); sys.exit() # Quit cleanly.
            # Handle continue event (pressing Return/Enter key).
            if event.type == KEYDOWN and event.key == K_RETURN:
                beginning = False # Exit the loop to proceed.


# Function to display the game instructions/rules screen.
def showInstructions():
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("How to Play Blackjack")
    screen.blit(pokerGreen, (0, 0)) # Draw background.

    # List containing instruction text lines, font, color, and Y position.
    instructions = [
        # Section headers are orange and larger font.
        ("Goal:", text_SubHeading, orange, 50),
        # Explanations are white and normal font.
        ("--> Get closer to 21 than the dealer without going over.", text_Normal, white, 90),
        ("Cards:", text_SubHeading, orange, 130),
        ("--> 2-10 = Face Value | J, Q, K = 10 | Ace = 1 or 11.", text_Normal, white, 170),
        ("Actions:", text_SubHeading, orange, 210),
        ("--> Hit (H): Take another card.", text_Normal, white, 250),
        ("--> Pass/Stand (P): Keep your hand and end your turn.", text_Normal, white, 290),
        # Dynamically include the Sabotage key name and cost.
        (f"--> Sabotage ({pygame.key.name(SABOTAGE_KEY).upper()}): Cost ${SABOTAGE_COST}. Force card on opponent.", text_Normal, white, 330),
        ("Outcomes:", text_SubHeading, orange, 370),
        ("--> Bust: Score over 21 (Lose).", text_Normal, white, 410),
        # Clarify Blackjack payout.
        ("--> Blackjack: First two cards total 21 (Pays 2:1).", text_Normal, white, 450),
        ("--> Push: Tie with Dealer (Bet returned).", text_Normal, white, 490),
        ("Betting:", text_SubHeading, orange, 530),
        ("--> Start with $100. Place bets before round.", text_Normal, white, 570),
        ("Sabotage Rules:", text_SubHeading, orange, 610),
         # Clarify when Sabotage is allowed.
        ("--> Cannot target players who are Standing, Busted, or have Blackjack.", text_Normal, white, 650),
    ]

    # Loop through the instructions list and draw each line using add_text.
    for text, font, color, y_pos in instructions:
         add_text(text, font, screen, halfWidth, y_pos, color) # Centered horizontally.

    # Display prompt to continue at the bottom.
    add_text("PRESS RETURN TO CONTINUE", text_Bold, screen, halfWidth, screenHeight - 40, white)
    pygame.display.flip() # Update screen.

    # Wait loop for Return key or Quit.
    showing = True
    while showing:
        pygame.time.Clock().tick(30)
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit(); sys.exit()
            if event.type == KEYDOWN and event.key == K_RETURN:
                showing = False # Exit loop.


# Function to display a screen when all players are bankrupt.
def showAllPlayersOutScreen():
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("Game Over - All Players Out")
    screen.blit(pokerGreen, (0, 0)) # Draw background.
    # Display informative messages.
    add_text("All Players Are Out!", text_Heading, screen, halfWidth, halfHeight - 60, orange)
    add_text("Game Over", text_SubHeading, screen, halfWidth, halfHeight, white)
    # Prompt the user to quit.
    add_text("Press ESCAPE to Quit", text_Bold, screen, halfWidth, halfHeight + 60, orange)
    pygame.display.flip() # Update screen.
    # Wait loop: Only exits when user quits (Escape or window close).
    waiting_for_quit = True
    while waiting_for_quit:
        pygame.time.Clock().tick(30)
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit(); sys.exit() # Quit cleanly.


# Function to get the number of players (1-5) from the user via keyboard input.
def getNumberOfPlayers():
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("Enter Number of Players")
    # String containing allowed input characters (digits 1 through 5).
    validNumbers = "12345"
    userString = "" # Stores the single digit entered by the user.
    num_players = 0 # Will hold the validated number of players.
    getting_input = True
    # Input loop: Continues until a valid number (1-5) is entered and confirmed.
    while getting_input:
        screen.blit(pokerGreen, (0, 0)) # Redraw background each frame.
        # Display prompt text.
        add_text("Enter number of players (1-5):", text_Bold, screen, halfWidth, halfHeight - 50, orange)
        # Display the entered digit, or an underscore if nothing entered yet.
        display_text = userString if userString else "_"
        add_text(display_text, text_SubHeading, screen, halfWidth, halfHeight, white)
        # Display confirmation instruction.
        add_text("PRESS RETURN TO CONFIRM", text_Bold, screen, halfWidth, halfHeight + 50, orange)
        pygame.display.flip() # Update screen.
        # Event handling for keyboard input.
        pygame.time.Clock().tick(30)
        for event in pygame.event.get():
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit(); sys.exit()
            if event.type == KEYDOWN:
                key_name = pygame.key.name(event.key) # Get the name of the key pressed (e.g., '1', 'backspace').
                # If a valid digit (1-5) is pressed and no digit is entered yet:
                if key_name in validNumbers and len(userString) < 1:
                    userString = key_name # Store the single digit.
                # If Backspace is pressed:
                elif event.key == K_BACKSPACE:
                    userString = "" # Clear the input.
                # If Return/Enter is pressed and a digit has been entered:
                elif event.key == K_RETURN and len(userString) == 1:
                    try:
                        # Convert the entered digit string to an integer.
                        num_players = int(userString)
                        # Validate if the number is within the allowed range (1-5).
                        if 1 <= num_players <= 5:
                           getting_input = False # Valid input, exit the loop.
                        else:
                            # Should not happen due to validNumbers check, but good practice.
                            print("Invalid number (must be 1-5).")
                            userString = "" # Reset input on error.
                    except ValueError:
                        # Should not happen if validNumbers is correct.
                        print("Invalid input.")
                        userString = "" # Reset input on error.

    return num_players # Return the validated number of players.


# Function to get the names for each player via keyboard input.
def getPlayerNames(num_players):
    global players # We need to modify the global 'players' list.
    players = [] # Clear any existing players before adding new ones.
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("Enter Player Names")
    # Define allowed characters for names (letters, numbers, space).
    validCharacters = "abcdefghijklmnopqrstuvwxyz1234567890 "
    max_name_length = 10 # Set a maximum length for player names.

    # Loop 'num_players' times to get a name for each player.
    for i in range(num_players):
        userString = "" # Stores the name currently being typed.
        getting_name = True
        # Input loop for the current player's name.
        while getting_name:
            screen.blit(pokerGreen, (0, 0)) # Redraw background.
            # Display prompt indicating which player's name is being entered.
            prompt = f"Enter Player {i + 1}'s name (max {max_name_length} chars):"
            add_text(prompt, text_Bold, screen, halfWidth, halfHeight - 50, orange)
            # Display the name being typed, or an underscore if empty.
            display_name = userString if userString else "_"
            add_text(display_name, text_SubHeading, screen, halfWidth, halfHeight, white)
            # Change confirmation text for the last player.
            if i == num_players - 1:
                confirm_text = "PRESS RETURN TO START"
            else:
                confirm_text = "PRESS RETURN TO ADD NAME"
            add_text(confirm_text, text_Bold, screen, halfWidth, halfHeight + 50, orange)
            pygame.display.flip() # Update screen.
            # Event handling for name input.
            pygame.time.Clock().tick(30)
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit(); sys.exit()
                if event.type == KEYDOWN:
                    key_char = event.unicode # Get the actual character typed (handles shifts, etc.).
                    # If the typed character is valid and name isn't too long:
                    if key_char.lower() in validCharacters and len(userString) < max_name_length:
                        userString += key_char # Add character to the name string.
                    # If Backspace is pressed:
                    elif event.key == K_BACKSPACE:
                        userString = userString[:-1] # Remove the last character.
                    # If Return/Enter is pressed and the name is not just whitespace:
                    elif event.key == K_RETURN and userString.strip(): # .strip() removes leading/trailing spaces.
                        # Create a new Player object with the entered name.
                        new_player = Player(userString.strip())
                        # Add the new player to the global 'players' list.
                        players.append(new_player)
                        getting_name = False # Exit the inner loop to get the next name or finish.


# Function to calculate and set the X, Y screen coordinates for players and the dealer.
# This helps arrange them visually on the screen.
def fixCoordinates():
    global players, dealer # Needs access to global player list and dealer object.
    # Consider only players who are currently active (not 'is_out').
    active_players = [p for p in players if not p.is_out]
    num_players = len(active_players) # Number of players to position.

    # Dealer position is fixed near the top center.
    dealer.x = halfWidth
    dealer.y = 150 # Y position for dealer.

    # --- Player Positioning ---
    # Players are positioned in a row near the bottom of the screen.
    player_y = screenHeight - 200 # Fixed Y coordinate for all players.
    # Define margins from the screen edges and gap between players.
    horizontal_margin = 100
    total_player_width_area = screenWidth - (2 * horizontal_margin) # Total width available for players.
    gap_between_players = 50

    # Only calculate positions if there are active players.
    if num_players > 0:
        # Estimate the horizontal space needed for each player's area (cards + text).
        player_area_width = 200 # Adjust this based on visual needs.
        # Calculate the total width required for all player areas plus the gaps between them.
        total_needed_width = (player_area_width * num_players) + (gap_between_players * (num_players - 1))

        # Calculate the starting X coordinate to center the entire block of players horizontally.
        # Start at the left margin, then add half the leftover space.
        start_x = horizontal_margin + max(0, (total_player_width_area - total_needed_width) / 2)
        # Calculate the X coordinate for the center of the *first* player's area.
        first_player_center_x = start_x + (player_area_width / 2)

        # Iterate through the *active* players and assign their calculated coordinates.
        current_player_index = 0
        for player in players: # Iterate the original list to maybe keep order?
             if not player.is_out: # Only position active players.
                 # Calculate the center X for this player's area.
                 player.x = first_player_center_x + current_player_index * (player_area_width + gap_between_players)
                 player.y = player_y # Assign the fixed Y coordinate.
                 current_player_index += 1 # Move to the next position index.


# Function to get bets from all active players via keyboard input.
def getPlayerBets():
    global players # Needs the global player list.
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("Place Your Bets")
    validNumbers = "0123456789" # Allowed digits for bet input.
    max_bet_digits = 4 # Limit maximum bet input length (e.g., up to $9999).

    # Filter out players who are already out of the game.
    active_players = [p for p in players if not p.is_out]
    # If no players are active, skip the betting phase.
    if not active_players:
        print("No active players to place bets.")
        return

    current_player_index = 0
    # Loop through each active player to get their bet.
    while current_player_index < len(active_players):
        player = active_players[current_player_index]

        # Edge case: If a player starts a round with $0, give them $1 so they *can* bet.
        # Otherwise they might get stuck if the minimum bet is > 0.
        if player.bank <= 0:
             print(f"{player.name} has no money, giving $1 to allow betting.")
             player.bank = 1

        # Input loop for the current player's bet amount.
        userString = "" # Stores the digits typed for the bet.
        getting_bet = True
        error_message = "" # Stores feedback for invalid bet attempts.
        while getting_bet:
            screen.blit(pokerGreen, (0, 0)) # Redraw background.
            # Display prompt showing whose turn it is and their current bank.
            prompt = f"{player.name}'s turn. Bank: ${player.bank}. Enter bet:"
            add_text(prompt, text_Bold, screen, halfWidth, halfHeight - 80, orange)
            # Display the bet amount being typed, or "$_" if empty.
            display_bet = "$" + userString if userString else "$_"
            add_text(display_bet, text_SubHeading, screen, halfWidth, halfHeight - 20, white)
            # Display confirmation instruction.
            confirm_text = "PRESS RETURN TO CONFIRM BET"
            add_text(confirm_text, text_Bold, screen, halfWidth, halfHeight + 30, orange)
            # Show error message below if one exists.
            if error_message:
                add_text(error_message, text_Bold, screen, halfWidth, halfHeight + 80, red)
            pygame.display.flip() # Update screen.
            # Event handling for bet input.
            pygame.time.Clock().tick(30)
            for event in pygame.event.get():
                if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                    pygame.quit(); sys.exit()
                if event.type == KEYDOWN:
                    key_name = pygame.key.name(event.key) # Get key name (e.g., '1', '0').
                    # If a valid digit is pressed and length limit not reached:
                    if key_name in validNumbers and len(userString) < max_bet_digits:
                        # Prevent leading zeros unless it's the only digit (e.g., allow '0' but not '01').
                        if key_name == '0' and len(userString) == 0 and max_bet_digits > 1:
                             pass # Skip adding the leading zero.
                        else:
                             userString += key_name # Add the digit.
                    # If Backspace is pressed:
                    elif event.key == K_BACKSPACE:
                        userString = userString[:-1] # Remove last digit.
                    # If Return/Enter is pressed:
                    elif event.key == K_RETURN:
                        # Check if any amount was entered.
                        if not userString:
                            error_message = "Please enter a bet amount."
                            continue # Go back to the start of the input loop.

                        # Validate the entered amount.
                        try:
                            bet_amount = int(userString) # Convert string to integer.
                            # Check if bet is positive.
                            if bet_amount <= 0:
                                error_message = "Bet must be greater than $0."
                                userString = "" # Clear input on error.
                            # Check if player can afford the bet.
                            elif bet_amount > player.bank:
                                error_message = f"Cannot bet more than your bank (${player.bank})."
                                userString = "" # Clear input on error.
                            # Bet is valid!
                            else:
                                # Use the player's placeBet method.
                                if player.placeBet(bet_amount):
                                    print(f"{player.name} bets ${bet_amount}.") # Log to console.
                                    getting_bet = False # Exit the input loop for this player.
                                    error_message = "" # Clear any previous error message.
                                else:
                                    # This case should ideally be caught by the checks above.
                                    error_message = "Invalid bet amount (internal error)."
                                    userString = ""
                        except ValueError:
                            # Handle cases where input is not a valid integer (e.g., empty after backspace).
                            error_message = "Invalid number entered."
                            userString = "" # Clear invalid input.

        # Move to the next active player.
        current_player_index += 1


# --- Core Game Round Functions ---

# Function to create a new, shuffled deck for the dealer.
# Usually called at the very start of the game, but could be used between rounds if needed.
def newDeck():
    global dealer
    # Re-initialize the deck object within the existing dealer instance.
    dealer.deck = Deck()
    dealer.deck.createDeck()
    dealer.deck.shuffleDeck()
    print("New deck created and shuffled.") # Console confirmation.


# Function to deal the initial two cards to the dealer and all active players.
# Returns True on success, False if a critical error occurs (e.g., deck empty).
def createHands():
    global dealer, players
    print("Dealing hands...") # Log start of dealing.
    # Reset and create the dealer's hand first. Check for errors (like empty deck).
    # The createDealerHand method now returns True/False for success/failure.
    if not dealer.createDealerHand():
         print("CRITICAL: Failed to create dealer hand (deck issue?). Aborting round setup.")
         return False # Signal critical failure.

    # Get the list of players currently in the game.
    active_players = [p for p in players if not p.is_out]
    # Deal two rounds of cards, one card per player per round.
    for round_num in range(2): # Deal round 1, then round 2.
        for player in active_players:
             card = dealer.dealCard() # Get one card from the dealer's deck.
             if card:
                 player.addCard(card) # Add the card to the player's hand.
             else:
                  # This is critical if the deck runs out during the *initial* deal.
                  print(f"CRITICAL ERROR: Deck empty while dealing initial card to {player.name}. Aborting round setup.")
                  return False # Signal critical failure.
    print("Initial hands dealt successfully.")
    return True # Signal successful dealing.


# Function to check for initial Blackjacks (21 on first two cards) for players.
# Dealer Blackjack check is handled within dealer.createDealerHand().
def checkBlackJack():
    global players # Need access to the players list.
    # Dealer BJ already checked.

    # Check active players for Blackjack.
    active_players = [p for p in players if not p.is_out]
    for player in active_players:
        # Ensure the check is only on the initial two cards.
        if len(player.hand) == 2:
            # Calculate count *just* for these two cards (should be up-to-date, but safe).
            player.countCards()
            if player.count == 21:
                print(f"{player.name} has Blackjack!")
                player.blackjack = True # Set the player's Blackjack flag.
                player.stood = True     # Blackjack automatically means the player stands.


# --- Consolidated Game Screen Drawing Function ---
# Draws the entire game state (background, dealer, players, messages) onto the screen.
def drawGameScreen(surface, dealer_revealed=False, message="", message_color=white):
    # Safety check for a valid drawing surface.
    if not surface:
         print("Error: Attempted to draw on an invalid surface.")
         return
    # 1. Draw the background image/color first (clears previous frame).
    surface.blit(pokerGreen, (0, 0))
    # 2. Draw the dealer's hand using the dealer's drawHand method.
    # Pass 'dealer_revealed' to control if the second card is hidden.
    dealer.drawHand(surface, revealed=dealer_revealed)
    # 3. Draw hands for all active players using their drawHand methods.
    active_players = [p for p in players if not p.is_out]
    for player in active_players:
        player.drawHand(surface)
    # 4. Display any temporary messages (e.g., for Sabotage results, errors).
    if message:
         # Position the message centrally on the screen.
         add_text(message, text_Bold, surface, halfWidth, halfHeight, message_color)
    # 5. Update the entire screen to show all the drawn elements.
    pygame.display.flip()


# --- UI Function for Sabotage Target Selection ---
# Provides an interface for the sabotaging player to choose a target.
def selectPlayerToSabotage(sabotager, screen):
    # Determine eligible targets based on game rules:
    # - Must be another player (not self).
    # - Must still be in the game (not is_out).
    # - Must not be already Busted.
    # - Must not have Blackjack.
    # - Must not have already chosen to Stand.
    eligible_targets = [p for p in players if p is not sabotager and
                                             not p.is_out and
                                             not p.bust and
                                             not p.blackjack and
                                             not p.stood]

    # If no valid targets exist:
    if not eligible_targets:
        # Display a message on screen indicating no targets available.
        drawGameScreen(screen, message=f"No valid targets to Sabotage.", message_color=orange)
        pygame.time.wait(1500) # Pause briefly to show the message.
        return None # Return None to indicate no target was selected/available.

    # --- UI Loop for Selection ---
    selected_index = 0 # Index of the currently highlighted target in the eligible_targets list.
    selecting = True
    while selecting:
        # --- Drawing the Selection Screen ---
        # 1. Redraw the standard game screen in the background for context.
        #    Dealer's hand is usually kept hidden during player turns/selection.
        drawGameScreen(screen, dealer_revealed=False)

        # 2. --- Overlay the Selection Prompt and Options ---
        # Define starting Y position for the overlay text.
        prompt_y = halfHeight - 120
        # Display the main prompt.
        add_text(f"{sabotager.name}, select target to Sabotage:", text_Bold, screen, halfWidth, prompt_y, orange)
        prompt_y += 30 # Move down for next line.
        # Show the cost and the player's current bank balance.
        add_text(f"(Cost: ${SABOTAGE_COST}, Your Bank: ${sabotager.bank})", text_Normal, screen, halfWidth, prompt_y, white)
        prompt_y += 30 # Move down.
        # Provide instructions for using the selection UI.
        add_text("(UP/DOWN arrows, RETURN to confirm, ESC to cancel)", text_Normal, screen, halfWidth, prompt_y, white)
        prompt_y += 40 # Add space before listing target names.

        # 3. List the eligible targets, highlighting the currently selected one.
        for i, target_player in enumerate(eligible_targets):
            # Use blue color for highlighted target, white for others.
            color = blue if i == selected_index else white
            # Display useful info about the target (Name, Count, Bank).
            target_info = f"{target_player.name} (Count: {target_player.count}, Bank: ${target_player.bank})"
            # Calculate Y position for this target name.
            y_pos = prompt_y + (i * 30)
            add_text(target_info, text_Normal, screen, halfWidth, y_pos, color) # Draw centered.

        # 4. Update the display to show the overlaid selection interface.
        pygame.display.flip()
        # --- End Drawing ---

        # --- Event Handling for Selection Input ---
        pygame.time.Clock().tick(30) # Limit loop speed.
        for event in pygame.event.get():
            if event.type == QUIT:
                pygame.quit(); sys.exit() # Allow quitting during selection.
            if event.type == KEYDOWN:
                # Handle Escape key to cancel Sabotage selection.
                if event.key == K_ESCAPE:
                    return None # Return None to indicate cancellation.
                # Navigate the target list using UP and DOWN arrow keys.
                elif event.key == K_UP:
                    # Decrement index, wrap around using modulo.
                    selected_index = (selected_index - 1) % len(eligible_targets)
                elif event.key == K_DOWN:
                    # Increment index, wrap around using modulo.
                    selected_index = (selected_index + 1) % len(eligible_targets)
                # Confirm the selected target with Return/Enter key.
                elif event.key == K_RETURN:
                    # Return the actual Player object that was selected.
                    return eligible_targets[selected_index]

    # This part should ideally not be reached if the loop logic is correct.
    return None # Default return if loop somehow exits unexpectedly.


# --- Function for Player Turns ---
# Manages the sequence of actions for each active player (Hit, Pass, Sabotage).
def playTurns():
    global players, dealer # Access global game objects.
    # Get the main screen surface (should be initialized already).
    screen = pygame.display.get_surface()
    # Failsafe: If screen is somehow not available, re-initialize it.
    if not screen:
        print("Error: Screen surface not available in playTurns. Re-initializing.")
        screen = pygame.display.set_mode((screenWidth, screenHeight))
        pygame.display.set_caption("Play Round - Blackjack")

    # Get a list of players who are currently active (not out).
    active_players = [p for p in players if not p.is_out]

    # Iterate through each active player for their turn.
    # Using enumerate provides both the index and the player object, though index isn't used here.
    for turn_index, currentPlayer in enumerate(active_players):

        # --- Pre-Turn Checks ---
        # Skip the turn entirely if the player:
        # - Already has Blackjack (automatically stands).
        # - Is already Busted from a previous action (like Sabotage).
        # - Has already chosen to Stand in a previous interaction (shouldn't happen here, but safe).
        if currentPlayer.blackjack or currentPlayer.bust or currentPlayer.stood:
            currentPlayer.currentTurn = False # Ensure the 'current turn' flag is off.
            continue # Skip to the next player in the list.

        # --- Start Player's Turn ---
        currentPlayer.currentTurn = True # Set flag to highlight player, show actions.
        print(f"\n--- {currentPlayer.name}'s Turn ---") # Log turn start to console.

        # Action Loop: Keeps asking the player for actions until their turn ends.
        # A turn ends if the player Stands, Busts, or successfully Sabotages.
        action_taken_this_turn = False # Flag becomes True when turn should end.
        while not action_taken_this_turn:
            # 1. Draw the current game screen. Shows player's hand, options, etc.
            #    Dealer's second card remains hidden during player turns.
            drawGameScreen(screen, dealer_revealed=False)
            # 2. Print hand/count to console (useful for debugging).
            currentPlayer.printHand()

            # 3. Get the player's action choice (1:Hit, 2:Pass, 3:Sabotage) via key press.
            choice = currentPlayer.askChoice()

            # --- Process Player's Choice ---

            # 4a. Handle HIT Action (Choice = 1)
            if choice == 1:
                print(f"{currentPlayer.name} hits.")
                hitCard = dealer.dealCard() # Get a card from the dealer's deck.
                if hitCard: # Check if a card was successfully dealt (deck not empty).
                    currentPlayer.addCard(hitCard) # Add the card to player's hand (updates count).
                    print(f"  Received: {hitCard.label} of {hitCard.suit}") # Log the card received.
                    # Check for immediate consequences of the hit:
                    if currentPlayer.count > 21:
                        print(f"{currentPlayer.name} busts!")
                        currentPlayer.bust = True # Set the bust flag.
                        action_taken_this_turn = True # Turn ends immediately on bust.
                    elif currentPlayer.count == 21:
                         print(f"{currentPlayer.name} has 21!")
                         # Player automatically stands if they hit exactly 21.
                         currentPlayer.stood = True # Mark as stood.
                         action_taken_this_turn = True # Turn ends.
                    # If count is < 21, the loop continues, asking for another action.
                else:
                    # Handle critical error if deck runs out during a hit.
                    print("CRITICAL ERROR: Deck empty during hit!")
                    # Should probably end the turn/round gracefully here.
                    action_taken_this_turn = True # End turn if no cards left.

            # 4b. Handle PASS/STAND Action (Choice = 2)
            elif choice == 2:
                print(f"{currentPlayer.name} stands.")
                currentPlayer.stood = True # Set the stood flag.
                action_taken_this_turn = True # Turn ends.

            # 4c. Handle SABOTAGE Action (Choice = 3)
            elif choice == 3:
                print(f"{currentPlayer.name} attempts to Sabotage...")
                # First, check if the player can afford the sabotage cost.
                if currentPlayer.bank >= SABOTAGE_COST:
                    # If affordable, initiate the target selection UI.
                    targetPlayer = selectPlayerToSabotage(currentPlayer, screen)

                    # If a target was successfully selected (not cancelled):
                    if targetPlayer:
                        print(f"{currentPlayer.name} targets {targetPlayer.name} for Sabotage!")
                        # --- Execute Sabotage ---
                        # 1. Deduct cost from the sabotaging player.
                        currentPlayer.bank -= SABOTAGE_COST
                        print(f"  {currentPlayer.name} pays ${SABOTAGE_COST}.")

                        # 2. Deal one card to the *target* player.
                        sabotageCard = dealer.dealCard()
                        if sabotageCard: # Check if card dealt successfully.
                             print(f"  Dealing sabotage card ({sabotageCard.label} of {sabotageCard.suit}) to {targetPlayer.name}...")
                             targetPlayer.addCard(sabotageCard) # Add card to target's hand (updates their count).
                             targetPlayer.printHand() # Show target's updated hand in console.

                             # Display result message on screen temporarily.
                             sabotage_msg = f"{currentPlayer.name} forced {targetPlayer.name} to take a {sabotageCard.label}!"
                             drawGameScreen(screen, message=sabotage_msg, message_color=orange)
                             pygame.time.wait(2000) # Pause 2 seconds to show message.

                             # 3. Check if the Sabotage caused the target to Bust.
                             if targetPlayer.count > 21:
                                 print(f"  {targetPlayer.name} BUSTED due to Sabotage!")
                                 targetPlayer.bust = True # Set target's bust flag.
                                 # Display bust message on screen.
                                 bust_msg = f"{targetPlayer.name} BUSTED from Sabotage!"
                                 drawGameScreen(screen, message=bust_msg, message_color=red)
                                 pygame.time.wait(2000) # Pause 2 seconds.

                             # 4. Sabotager's turn ends after a successful sabotage attempt.
                             action_taken_this_turn = True
                        else:
                             # Handle error if deck runs out during Sabotage deal.
                             print("ERROR: Deck empty during Sabotage deal attempt!")
                             # Refund cost? Maybe not, part of the risk.
                             # Let the player know the attempt failed.
                             drawGameScreen(screen, message="Sabotage failed: Deck empty!", message_color=red)
                             pygame.time.wait(1500)
                             # Player returns to action choice loop (Hit/Pass/Sabotage again).
                             # Turn does NOT end here.

                    else: # Target selection was cancelled (Escape key) or no valid targets.
                        print("  Sabotage cancelled or no valid target found.")
                        # Player returns to action choice loop. Turn does not end.
                else: # Player cannot afford Sabotage.
                    print(f"  Not enough money to Sabotage (Need ${SABOTAGE_COST}, Have ${currentPlayer.bank}).")
                    # Display message on screen indicating insufficient funds.
                    drawGameScreen(screen, message=f"Need ${SABOTAGE_COST} to Sabotage!", message_color=red)
                    pygame.time.wait(1500) # Pause briefly.
                    # Player returns to action choice loop. Turn does not end.

            # 4d. Handle Quit or Unexpected Choice
            else:
                # This case handles Quit events captured by askChoice or unexpected return values.
                print(f"Invalid choice ({choice}) or quit signal received during turn.")
                pygame.quit()
                sys.exit()

            # --- End of Action Processing ---
            # Brief pause/redraw before the next action *only* if the turn hasn't ended yet.
            if not action_taken_this_turn:
                 drawGameScreen(screen, dealer_revealed=False) # Redraw state.
                 pygame.time.wait(100) # Small pause (0.1 seconds).

        # --- End of the current player's turn loop ---
        currentPlayer.currentTurn = False # Turn flag off before moving to next player.
        # Brief pause/display update after turn ends to show the final state (Bust/Stand).
        drawGameScreen(screen, dealer_revealed=False)
        pygame.time.wait(500) # Wait half a second before starting the next player's turn.

    # --- All Player Turns Completed ---
    print("\n--- All Player Turns Complete ---")


# --- Function for Dealer's Turn ---
# Handles the dealer playing their hand according to standard Blackjack rules.
# Dealer must hit on 16 or less, and stand on 17 or more.
def dealerTurn():
    global dealer # Access the global dealer object.
    print("\n--- Dealer's Turn ---")
    # Ensure the dealer's count is accurate before starting the turn.
    dealer.countCards()

    # Print initial dealer hand and count to console (hand should be revealed now).
    dealer.printDealerHand()
    dealer.printDealerCount()

    # Get the screen surface to update display after each dealer action.
    screen = pygame.display.get_surface()

    # Dealer hits as long as their count is 16 or less.
    while dealer.count < 17:
         print("Dealer hits.")
         # Pause briefly so players can see the action happening.
         pygame.time.wait(1000) # Wait 1 second.

         # Use the dealer's hit method (gets card, adds to hand, updates count).
         dealer.hit()

         # Safety check: Did the hit actually add a card? (Deck might be empty).
         if not dealer.hand or not dealer.hand[-1]: # Check if hand is empty or last card is None.
              print("Dealer hit failed - deck likely empty. Dealer stops hitting.")
              break # Stop the hitting loop if deck issue occurs.

         # Print updated hand and count to console after the hit.
         dealer.printDealerHand()
         dealer.printDealerCount()

         # Update the game screen to show the new card and count (dealer hand revealed).
         if screen: drawGameScreen(screen, dealer_revealed=True)
         pygame.time.wait(500) # Pause briefly after showing the hit.


    # --- Determine outcome of dealer's turn ---
    dealer_bust = False
    if dealer.count > 21:
        print("Dealer busts!")
        dealer_bust = True
    else:
         # If count is 17 or more (and not busted), dealer stands.
         print(f"Dealer stands with {dealer.count}.")

    # Final screen update showing dealer's final hand and status (Bust or Stand).
    if screen: drawGameScreen(screen, dealer_revealed=True)
    pygame.time.wait(1000) # Pause 1 second after dealer finishes.

    # Return True if the dealer busted, False otherwise.
    return dealer_bust


# --- Function to Compare Hands and Determine Payouts ---
# Compares each active player's hand against the dealer's hand to determine win/loss/push.
# Applies the appropriate payout to the player's bank using player.applyBet().
def compareCountsAndPayout():
    global players, dealer # Access global objects.
    print("\n--- Round Results ---")
    # Get the dealer's final score and status.
    dealer_score = dealer.count
    dealer_bust = dealer.count > 21
    dealer_has_blackjack = dealer.blackjack

    # Iterate through active players to determine their outcome.
    active_players = [p for p in players if not p.is_out]
    for player in active_players:
        # Skip payout logic if player didn't place a bet (e.g., might happen if they had $0 and couldn't bet $1).
        # Also skip if they busted *before* betting? Unlikely, but safe check.
        # Exception: Player with Blackjack *always* gets compared, even if bet was 0 (shouldn't happen).
        if player.bet <= 0 and not player.blackjack:
             # print(f"{player.name} did not bet or had $0, skipping payout resolution.") # Optional log
             continue # Move to the next player.

        # Get the player's final state for comparison.
        player_score = player.count
        player_bust = player.bust
        player_has_blackjack = player.blackjack

        # --- Payout Logic ---
        # Log the comparison for clarity.
        player_status = f"{' BJ' if player_has_blackjack else ''}{' Bust' if player_bust else ''}"
        dealer_status = f"{' BJ' if dealer_has_blackjack else ''}{' Bust' if dealer_bust else ''}"
        print(f"Comparing {player.name} ({player_score}{player_status}) vs Dealer ({dealer_score}{dealer_status})")

        # Case 1: Player Busted
        if player_bust:
            print(f" -> {player.name} busted. Loses bet ${player.bet}.")
            # Factor 0: Lose bet (bank change = 0, bet was already deducted).
            player.applyBet(0)

        # Case 2: Player has Blackjack
        elif player_has_blackjack:
            # If dealer also has Blackjack, it's a push.
            if dealer_has_blackjack:
                print(f" -> Push! {player.name} Blackjack vs Dealer Blackjack. Bet ${player.bet} returned.")
                # Factor 1: Push (bank change = +bet, gets original bet back).
                player.applyBet(1)
            # If dealer does not have Blackjack, player wins Blackjack payout.
            else:
                # Blackjack pays 2:1 (same as regular win in this version).
                print(f" -> {player.name} wins with Blackjack! Bet ${player.bet} pays 2:1.")
                # Factor 2: Win (bank change = +2 * bet, gets bet back + winnings).
                player.applyBet(2)

        # Case 3: Dealer Busted (and player did not bust, handled in Case 1)
        elif dealer_bust:
            print(f" -> {player.name} wins (Dealer busted). Wins ${player.bet}.")
            # Player wins their bet.
            player.applyBet(2) # Factor 2: Win.

        # Case 4: Dealer has Blackjack (and player does not, handled in Case 2)
        elif dealer_has_blackjack:
             print(f" -> {player.name} loses to Dealer Blackjack. Loses bet ${player.bet}.")
             # Player loses their bet.
             player.applyBet(0) # Factor 0: Lose.

        # Case 5: Neither busted, neither has Blackjack - Compare scores.
        elif player_score > dealer_score:
            print(f" -> {player.name} wins ({player_score} vs {dealer_score}). Wins ${player.bet}.")
            player.applyBet(2) # Factor 2: Win.
        elif player_score == dealer_score:
            print(f" -> Push! ({player.name} {player_score} vs Dealer {dealer_score}). Bet ${player.bet} returned.")
            player.applyBet(1) # Factor 1: Push.
        else: # player_score < dealer_score
            print(f" -> {player.name} loses ({player_score} vs {dealer_score}). Loses bet ${player.bet}.")
            player.applyBet(0) # Factor 0: Lose.

        # Print the player's bank balance after the payout is applied.
        player.printBank()


# --- Function to Check for Game Winner ---
# Checks if any active player has reached the winning bank threshold.
# Returns: A list of winning player object(s) if condition met, otherwise None.
def checkWinner():
    global players
    winning_threshold = 500 # Bank balance required to win the game.
    winners = []            # List to hold player(s) who meet the condition.
    highest_bank_among_winners = -1 # Track highest bank *among those at/above threshold* to handle ties.

    # Check only players who are still actively in the game.
    active_players = [p for p in players if not p.is_out]
    if not active_players:
        return None # No winner possible if no players are left.

    # Find players at or above the winning threshold.
    for player in active_players:
        if player.bank >= winning_threshold:
            # Check if this player has a new highest score among potential winners.
            if player.bank > highest_bank_among_winners:
                 highest_bank_among_winners = player.bank
                 winners = [player] # This player is the new sole leader.
            # Check if this player ties the current highest score among winners.
            elif player.bank == highest_bank_among_winners:
                 winners.append(player) # Add to the list of tied winners.

    # If the 'winners' list is not empty, it means at least one player met the threshold.
    if winners:
        # Get names for display message.
        winner_names = ", ".join([w.name for w in winners])
        print(f"\n*** Game Over! Winner(s) reaching ${winning_threshold}: {winner_names} with ${highest_bank_among_winners}! ***")
        # Return the list containing the winning player object(s).
        return winners
    else:
        # No winner found this round.
        return None


# --- Function to Display End-of-Round Summary Screen ---
# Shows the results of the round (scores, banks) and prompts for the next round or exit.
def showEndRoundScreen(winner_list): # Takes the list returned by checkWinner (can be None or list of winners).
    global players, dealer # Access global objects for display.
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("Round Over")
    screen.blit(pokerGreen, (0, 0)) # Draw background.

    # --- Display Round Results Section ---
    start_y = 80        # Starting Y position for text elements.
    line_height = 35    # Vertical space between lines.
    # Title for the screen.
    add_text("Round Results", text_Heading, screen, halfWidth, start_y, orange); start_y += line_height + 10

    # Display Dealer's final status.
    dealer_status = f"Dealer Score: {dealer.count}"
    if dealer.count > 21: dealer_status += " (Busted)"
    elif dealer.blackjack: dealer_status += " (Blackjack)"
    add_text(dealer_status, text_Bold, screen, halfWidth, start_y, white); start_y += line_height

    # Header for player results.
    add_text("Player Results:", text_SubHeading, screen, halfWidth, start_y, orange); start_y += line_height

    # Display status and final bank balance for each active player.
    active_players = [p for p in players if not p.is_out]
    for player in active_players:
        # Construct the info string for the player.
        player_info = f"{player.name}: Score {player.count}"
        # Add status indicators (Bust, Blackjack, Stood).
        if player.bust: player_info += " (Busted)"
        elif player.blackjack: player_info += " (Blackjack)"
        elif player.stood: player_info += " (Stood)"
        # Add final bank balance after payouts.
        player_info += f" | Bank: ${player.bank}"
        # Draw the player info line.
        add_text(player_info, text_Normal, screen, halfWidth, start_y, white)
        start_y += line_height - 5 # Slightly less space between player lines.

    # --- Display Game Over Message OR Next Round Prompt ---
    start_y += 20 # Add some space before the final prompt.
    # If winner_list is not None and not empty, the game is over.
    if winner_list:
        winner_names = ", ".join([w.name for w in winner_list])
        win_message = f"Game Over! Winner(s): {winner_names}!"
        # Display the winning message prominently.
        add_text(win_message, text_Heading, screen, halfWidth, start_y, blue)
        # Prompt the user to exit the game.
        prompt_text = "PRESS ESCAPE TO EXIT"
        prompt_y_pos = screenHeight - 50 # Position near bottom.
        add_text(prompt_text, text_Bold, screen, halfWidth, prompt_y_pos, orange)
    # Otherwise, the game continues.
    else:
        # Prompt the user to start the next round.
        prompt_text = "PRESS RETURN FOR NEXT ROUND"
        prompt_y_pos = screenHeight - 50 # Position near bottom.
        add_text(prompt_text, text_Bold, screen, halfWidth, prompt_y_pos, orange)

    # Update the display to show the summary screen.
    pygame.display.flip()

    # --- Wait for User Input ---
    # Loop waits for Return (if game continues) or Escape/Quit.
    round_end_showing = True
    while round_end_showing:
        pygame.time.Clock().tick(30) # Limit speed.
        for event in pygame.event.get():
            # Handle Quit/Escape events (always allowed).
            if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                pygame.quit(); sys.exit() # Quit cleanly.
            # Handle Continue (Return key) *only* if the game is not over.
            if event.type == KEYDOWN and event.key == K_RETURN:
                if not winner_list: # If no winner was declared, Return proceeds.
                    round_end_showing = False # Exit the loop to start the next round.


# Function to reset dealer and player states for a new round.
def resetForNewRound():
    global players, dealer # Access global objects.
    print("\n--- Preparing for New Round ---")
    # Reset Dealer's hand, count, and flags.
    dealer.hand = []
    dealer.count = 0
    dealer.blackjack = False # Reset Blackjack flag specifically.
    # Reset state for all *active* players.
    active_players = [p for p in players if not p.is_out]
    for player in active_players:
        # Use the player's resetState method.
        player.resetState() # Resets hand, count, flags (bust, BJ, stood).
    print("Dealer and active player states reset.")


# Function to check for players who have run out of money and mark them as 'out'.
# Returns True if any players were newly marked as out, False otherwise.
def removeBrokePlayers():
    global players # Needs to modify player state.
    players_marked_out_this_call = [] # Track who was marked out just now.
    # Iterate through *all* players (checking 'is_out' prevents re-marking).
    for player in players:
        # Mark player as out if their bank is 0 or less AND they aren't already marked out.
        if player.bank <= 0 and not player.is_out:
            print(f"{player.name} is out of money (${player.bank}) and has been removed from the game!")
            player.is_out = True # Set the flag.
            players_marked_out_this_call.append(player) # Record who was removed.

    # Return whether any players were actually marked as out during this check.
    if players_marked_out_this_call:
         print(f"Removed {len(players_marked_out_this_call)} bankrupt players this round.")
         return True
    else:
         return False


# --- Optional: Point Transfer Phase Function ---
# Placeholder for allowing players to give money between rounds.
def handlePointTransferPhase(screen):
     # If implementing this feature:
     # 1. Add UI to ask if anyone wants to transfer points.
     # 2. If yes, use a similar selection UI (like selectPlayerToSabotage)
     #    to choose the GIVER and the RECIPIENT.
     # 3. Get the AMOUNT to transfer via keyboard input.
     # 4. Validate the transfer using player.givePoints().
     # 5. Show confirmation/error messages.
     # 6. Loop until players indicate they are done transferring.
     # 7. Remember to redraw the screen appropriately during UI interactions.
     print("(Point Transfer Phase Skipped - Feature not implemented)")
     pass # Currently does nothing.


# === Main Game Function ===
# Contains the primary game loop and coordinates the different phases of the game.
def main():
    # Declare potentially modified global variables. gameOver is used, others might be if helper functions change.
    global players, dealer, gameOver

    # --- Initial Game Setup ---
    # Display introductory screens.
    startGame()          # Show welcome screen.
    showInstructions()   # Display rules (includes Sabotage & updated BJ payout).
    # Get game configuration from user.
    num_players = getNumberOfPlayers() # Get number of players (1-5).
    getPlayerNames(num_players)      # Get names for each player, creates Player objects.
    # Calculate initial screen positions for dealer and players.
    fixCoordinates()

    # --- Game Loop Initialization ---
    gameOver = False     # Flag to control the main game loop. Set to True when game ends.
    game_winner_list = None # Stores the winner(s) list when game ends (is None otherwise).
    # Initialize the main Pygame display surface. This surface is passed to drawing functions.
    screen = pygame.display.set_mode((screenWidth, screenHeight))
    pygame.display.set_caption("Blackjack Blitz - Main Game") # Set window title for game phase.

    # Main Game Loop: Continues as long as 'gameOver' is False.
    round_num = 1
    while not gameOver:
        print("\n" + "="*15 + f" Starting Round {round_num} " + "="*15)

        # --- Pre-Round Check ---
        # Check if there are any active players left before starting the round.
        active_players_exist = any(not p.is_out for p in players)
        if not active_players_exist:
             print("No active players remaining.")
             gameOver = True # End the game immediately if everyone is out.
             break # Exit the main game loop.

        # --- Start of Round Sequence ---
        # 0. Reset States: Prepare dealer and players for the new round.
        resetForNewRound()
        # Recalculate coordinates in case players were removed.
        fixCoordinates()

        # (Optional: Implement point transfer phase here if desired)
        # handlePointTransferPhase(screen)

        # 1. Betting Phase: Get bets from all active players.
        getPlayerBets()
        # Draw screen after betting to show placed bets.
        drawGameScreen(screen, dealer_revealed=False, message="Bets Placed!", message_color=white)
        pygame.time.wait(1500) # Pause briefly.

        # 2. Deal Initial Hands: Deal two cards each, handle potential deck errors.
        # createHands() returns False on critical deck error during initial deal.
        if not createHands():
             print("Critical error during initial deal (likely empty deck). Ending game.")
             gameOver = True
             break # Exit the main game loop.

        # Draw the initial game state after dealing hands. Dealer's second card hidden.
        drawGameScreen(screen, dealer_revealed=False, message="Dealing...", message_color=white)
        pygame.time.wait(1500) # Pause so players can see their initial hands.

        # 3. Check for Initial Blackjacks: Check dealer (done in createDealerHand) and players.
        checkBlackJack()
        # Update screen immediately to show any Blackjack indicators/overlays.
        drawGameScreen(screen, dealer_revealed=False)
        pygame.time.wait(1000) # Pause briefly if Blackjacks occurred.

        # 4. Player Turns: Handle sequence of Hit, Pass, and Sabotage actions for active players.
        playTurns() # Contains the core logic for player interactions.

        # 5. Dealer's Turn: Dealer plays their hand according to rules, if necessary.
        # Check if the dealer actually needs to play:
        # - Are there any players still in the round (not Busted, not Blackjack)?
        # - Does the dealer NOT have Blackjack already?
        players_still_in_round = any(not p.is_out and not p.bust and not p.blackjack for p in players)
        dealer_needs_to_play = players_still_in_round and not dealer.blackjack

        if dealer_needs_to_play:
            # Execute the dealer's turn logic (hit/stand). Returns True if dealer busted.
            dealer_bust = dealerTurn()
            # Screen is updated within dealerTurn function.
        else:
            # Announce why the dealer isn't playing.
            if dealer.blackjack:
                 print("\nDealer does not play (already has Blackjack).")
            elif not players_still_in_round:
                 print("\nDealer does not play (all players busted or have Blackjack).")
            # Ensure dealer's hand is fully revealed on screen even if they didn't hit.
            drawGameScreen(screen, dealer_revealed=True)
            pygame.time.wait(1000) # Pause to show revealed hand.

        # 6. Compare Hands and Payout Bets: Determine winners/losers/pushes and adjust banks.
        compareCountsAndPayout() # Uses the updated payout logic.
        pygame.time.wait(2000) # Pause after showing console results before summary screen.

        # 7. Check for Game Winner: See if any player reached the winning bank amount.
        game_winner_list = checkWinner() # Returns list of winners or None.
        if game_winner_list: # If checkWinner returns a non-None list:
            gameOver = True # Set flag to end the game after this round's summary.

        # 8. Show End of Round Screen: Display results summary, prompt for next round or exit.
        # Pass the winner info (or None) to the screen function to control the final prompt.
        showEndRoundScreen(game_winner_list)

        # --- Post-Round Cleanup & Checks (only if game isn't over yet) ---
        if not gameOver:
            # 9. Remove Bankrupt Players: Mark players with bank <= 0 as 'is_out'.
            if removeBrokePlayers(): # Returns True if anyone was removed.
                 fixCoordinates() # Update player layout if necessary for the next round.

            # 10. Final Check: If removing players resulted in NO active players left.
            if not any(not p.is_out for p in players):
                 print("All players are now out after round resolution!")
                 gameOver = True # Ensure game loop ends.
                 # The 'showAllPlayersOutScreen' will be called *after* the loop finishes.

            round_num += 1 # Increment round number for the next iteration.

    # === End of Main Game Loop ===

    # --- Post-Game Actions ---
    # Determine *why* the loop ended and show the appropriate final screen.
    # Case 1: Loop ended because everyone went bankrupt (and no winner was declared via threshold).
    if not any(not p.is_out for p in players) and not game_winner_list:
        # showEndRoundScreen was likely just shown, but this provides a specific final screen.
        showAllPlayersOutScreen() # Waits for Escape/Quit.
    # Case 2: Loop ended because a winner was found (game_winner_list is populated).
    elif game_winner_list:
        # The final prompt (Escape to Exit) was handled by showEndRoundScreen.
        print("Game finished with winner(s). Waiting for exit signal...")
        # Need a small loop here just to wait for the Quit signal from showEndRoundScreen's wait loop.
        waiting_exit = True
        while waiting_exit:
             pygame.time.Clock().tick(10)
             for event in pygame.event.get():
                  if event.type == QUIT or (event.type == KEYDOWN and event.key == K_ESCAPE):
                       waiting_exit = False # Exit this final wait.
    # Case 3: Other potential exit conditions (e.g., critical error break).
    else:
         print("Game loop ended for unspecified reason.")

    # Final message before the program terminates.
    print("\nExiting Blackjack game.")


# === Script Entry Point ===
# This block ensures the code inside only runs when the script is executed directly
# (not when imported as a module).
if __name__ == '__main__':
     try:
         # Start the main game logic.
         main()
     except SystemExit:
          # Catch clean exits initiated by sys.exit() (e.g., closing window, pressing Esc).
          print("Game exited cleanly via SystemExit.")
     except Exception as e:
         # Catch any unexpected errors during game execution.
         print(f"\n--- UNEXPECTED ERROR OCCURRED ---")
         print(f"Error Type: {type(e).__name__}")
         print(f"Error Message: {e}")
         # Import traceback to print detailed error information for debugging.
         import traceback
         traceback.print_exc()
         print("--- END TRACEBACK ---")
     finally:
         # This block *always* runs, whether the game finished normally,
         # exited early, or crashed due to an error.
         # Ensures Pygame resources are released properly.
         print("Executing finally block: Quitting Pygame.")
         pygame.quit()
         # Note: sys.exit() might have already been called, but calling pygame.quit()
         # again is generally safe and ensures cleanup.
